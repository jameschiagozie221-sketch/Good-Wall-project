# Animals Facts

A Pen created on CodePen.

Original URL: [https://codepen.io/jameschiagozie221-sketch/pen/YPpyBEB](https://codepen.io/jameschiagozie221-sketch/pen/YPpyBEB).

